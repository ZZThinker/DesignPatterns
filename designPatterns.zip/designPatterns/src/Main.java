public class Main {

    public static void main(String[] args) {
        /**
        Runtime为单例模式 饿汉型 静态常量
         **/
        System.out.println("Hello World!");
    }
}
